'''Extract calls to logging libraries from code Trees'''

class CodeScrape(object):
    '''
    classdocs
    '''


    def __init__(selfparams):
        '''
        Constructor
        '''
        pass
    
    