'''
Created on Feb 17, 2012

@author: conrad
'''

class Logwords(object):
    '''
    Extract Unique words from a logfile
    
    Group them by the Regexp Match they fit.
    
    Mask out stuff like Syslog Dates first..
    
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        
        
    def ExtractUniques(self):
        pass
    
    
    def GroupToRegex(self):
        pass
    
    
    